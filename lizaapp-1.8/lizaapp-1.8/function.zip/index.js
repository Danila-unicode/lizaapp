const https = require('https');

// Хранилище сигналов (в реальном проекте лучше использовать базу данных)
let signals = [];
let signalId = 1;

exports.handler = async (event) => {
    const method = event.httpMethod || event.method;
    const body = event.body ? JSON.parse(event.body) : {};
    const queryParams = event.queryStringParameters || {};
    
    console.log('Request:', { method, body, queryParams });
    
    // CORS headers
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Content-Type': 'application/json'
    };
    
    // Handle preflight requests
    if (method === 'OPTIONS') {
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({ success: true })
        };
    }
    
    try {
        if (method === 'POST' && body.action === 'signal') {
            // Отправка сигнала напрямую пользователю (без комнат)
            const signal = {
                id: signalId++,
                timestamp: Date.now(),
                from: body.from,
                to: body.to,
                type: body.type,
                data: body.data
            };
            
            signals.push(signal);
            console.log('Signal stored:', signal);
            
            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    success: true,
                    message: 'Сигнал отправлен',
                    signalId: signal.id,
                    timestamp: new Date().toISOString(),
                    totalSignals: signals.length
                })
            };
        }
        
        if (method === 'GET' && queryParams.action === 'signals') {
            // Получение сигналов для пользователя (без комнат)
            const userId = queryParams.userId;
            const since = parseInt(queryParams.since) || 0;
            
            const userSignals = signals.filter(signal => 
                signal.to === userId && signal.timestamp > since
            );
            
            console.log(`Signals for ${userId} since ${since}:`, userSignals.length);
            
            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    success: true,
                    signals: userSignals,
                    count: userSignals.length
                })
            };
        }
        
        return {
            statusCode: 400,
            headers,
            body: JSON.stringify({
                success: false,
                error: 'Неизвестный запрос'
            })
        };
        
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                success: false,
                error: error.message
            })
        };
    }
};
